var globalMainVars = {};
var ResultsList = React.createClass({
	getInitialState: function(){
		var d = {results : [] , next_page : '', previous_page : '' , current_page : ''};
		return {data: d};
	},
	updateFilter : function(sData){
		var callBack = function(that,token,status){
				var url = that.props.url.replace('__agent_user_name__',getCookie('web-gaff-user'));
				if(status != ''){
					url+='?status='+status;
				}
				$.ajax({
					url: getDomainName()+url,
					dataType: 'json',
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data) {
						that.setState({data: data});
						
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err) {
						if(xhr.status == 401){
							
							removeCookie('web-gaff-token');
							makeRequestWithTokenCookie(that,globalMainVars.currentCallBack);
						}
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			$('#spinner').show();
			makeRequestWithTokenCookie(this,callBack,sData);
	},
	componentDidMount: function() {
			
			var callBack = function(that,token){
				var url = that.props.url.replace('__agent_user_name__',getCookie('web-gaff-user'));
				$.ajax({
					url: getDomainName()+url,
					dataType: 'json',
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data) {
						that.setState({data: data});
						
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err) {
						if(xhr.status == 401){
							
							removeCookie('web-gaff-token');
							makeRequestWithTokenCookie(that,globalMainVars.currentCallBack);
						}
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			$('#spinner').show();
			makeRequestWithTokenCookie(this,callBack);
	},
	render : function(){
		globalMainVars.ResultList = this;
		var results = [];
		if(this.state.data.results){
			var rs = this.state.data.results;
			for(var i=0;i<rs.length;i++){
				results.push(<Result key={i} data={rs[i]} />);
			}
		}
		var clickPageHandler = function(event){
			var type = $(event.target).data('type');
			
			var pageUrl = '';
			if(type == 'next'){
				pageUrl = globalMainVars.ResultList.state.data.next_page;
			} else {
				pageUrl = globalMainVars.ResultList.state.data.previous_page;
			}
			globalMainVars.pageUrl = pageUrl;
			
			var callBack = function(that,token){
				$.ajax({
					url: globalMainVars.pageUrl,
					type: 'GET',
					cache: false,
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data){
						that.setState({data: data});
						globalMainVars.ResultList.setState({data: data});
						showPage('results_page','/results');
						$('.searchTabs.xs').removeAttr('style');
						
						 var swiper1 = new Swiper('.swiper1',{
							pagination: '.swiper-pagination1',
							paginationClickable: true,
							spaceBetween: 0,
							nextButton: '.swiper-button-next',
							prevButton: '.swiper-button-prev'
						});
						initiateMapSwiper();

						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err){
						if(xhr.status == 401){
								$('#token').val('');
								makeRequestWithTokenCookie(that,globalMainVars.currentCallBack);
						}
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			$('#spinner').show();
			makeRequestWithTokenCookie(globalMainVars.ResultList,callBack);
		};
		
		var nextPageClass = (this.state.data.next_page == '' || this.state.data.next_page == this.state.data.current_page) ? 'hidden btn' : 'btn';
		var prevPageClass = (this.state.data.previous_page == '' || this.state.data.previous_page == this.state.data.current_page)? 'hidden btn' : 'btn';
	
		return (
			<div className="container results nopadding">
				{results}
				<div className="pagination-control">
					<button className={prevPageClass} data-type="prev" onClick={clickPageHandler}> Prev</button>
					<button className={nextPageClass} data-type="next" onClick={clickPageHandler}> Next  </button>
				</div>
			</div>
		);
	}
});


var Proppicture = React.createClass({
	render : function(){
		return (
			<div className="swiper-slide"><img src={this.props.imgurl} align="middle" className="propertyImg" /></div>					
		);
	}
});

var Result = React.createClass({
	render : function(){
		return(
			<div className="col-xs-12 col-sm-6 col-md-6 col-lg-4 nopadding">
				<Mapresult data={this.props.data} />
			</div>
		)
	}
});

var MapSwipeResult = React.createClass({
	render : function(){
		return(
			<div className="swiper-slide">
				<Mapresult data={this.props.data} />
			</div>
		)
	}
});

var Mapresult = React.createClass({
	render : function(){
		var prop = this.props.data;

        

        var typearr = prop.title.split("|");
		var oLogo =  React.createElement('img', {src : this.props.data.owner_logo_url,style : {width: "45px", height: "45px"}});
		var propPic = React.createElement('img', {src : prop.pictures[0] , className : 'propertyImg' , align : 'middle' });
		var title = React.createElement('h4', {style : {whiteSpace: "nowrap", width: "152px" , overflow: 'hidden'}},
            typearr[0],
            React.createElement('span',{className:'seperator'}),
            typearr[1]
        );
		var desc = React.createElement('p', {style : {height: "42px", width: "150px" , overflow: 'hidden'}},prop.description.text);
		var bathrooms = prop.details['Bathrooms'] ? React.createElement('div', {className : 'bathIcon' },prop.details['Bathrooms']) : '';
		var parking = prop.details['Parking Space'] ? React.createElement('div', {className : 'carIcon' },prop.details['Parking Space']) : '';
		var bedrooms = prop.details['Bedrooms'] ? React.createElement('div', {className : 'bedIcon' },prop.details['Bedrooms']) : '';
		var heightSpec = prop.details['Total Floor Area'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Total Floor Area']+'ha') : '';
		var sizes = prop.details['sizes'] ? React.createElement('div', {className : 'heightSpec' },prop.details['sizes']) : '';
		var Size = prop.details['Size'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Size']) : '';
		
		var ber = null;
		if(prop.ber){
			var berno = prop.ber;
			berno = berno.toLowerCase();
			ber = React.createElement('img', {src : 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/ber/ber_'+berno+'.png' , className : 'berImg' });
		}
		var propPics = [];
		for(var j = 0; j < prop.pictures.length;j++){
			propPics.push(<Proppicture key={j} imgurl={prop.pictures[j]} />);
		}
		var onClickHandler = function(e){
			if($(e.target).hasClass('swiper-pagination-bullet') || $(e.target).hasClass('swiper-pagination') || $(e.target).hasClass('swiper-button-next') || $(e.target).hasClass('swiper-button-prev') || $(e.target).hasClass('likeCheck') ){
			}
		}
		
		
		return (
			
				<div className="cardWrap" data-url={prop.url}>
					<div className="card" >
						<div className="cardImgWrap internal">
							
							<div className="swiper-container swiper1">
								<div className="swiper-wrapper">
									{propPics}
								</div>
								<div className="swiper-pagination swiper-pagination1"></div>
								<div className="swiper-button-next"></div>
								<div className="swiper-button-prev"></div>
							</div>
							<div className="likeCheck">
								<input type="checkbox" id="property1" />
								<label for="property1" className="likeIcon"></label>
							</div>
                            {ber}
							<div className="authIcon">{oLogo}</div>
						</div>
						<div onClick={onClickHandler} className="cardSpec row">
							<div className="cardDisc col-md-6">
								{title}
								{desc}
							</div>
							<div className="cardPrice col-md-6 pull-right">
								<p>{prop.price}</p>
							</div>
							<div className="col-xs-12 cardDtl">
								{bathrooms}
								{parking}
								{bedrooms}
								{heightSpec}
								{Size}
								{sizes}
							</div>
						</div>
					</div>
				</div>
		);
	}
});

$(document).ready(function(){

	ReactDOM.render(
		<ResultsList url="api/v1/__agent_user_name__/get-agent-property/"  />,
		document.getElementById('searchResults')
	);
	
	$('.result_filter').on('click',function(){
		var status = $(this).attr('data-status');
		console.log(this);
		console.log(status);
		globalMainVars.ResultList.updateFilter(status);
	});
});
