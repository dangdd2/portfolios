var globalVar = {mob:{},desk:{},desk_result:{},searchMenues:[],apiCalled : false };
var SearchMenu = React.createClass({
		getInitialState: function() {
			globalVar.searchMenues.push(this);
			return {data: {
			}};
		},
		componentDidMount: function() {
			var callBack = function(that,token){
				$.ajax({
					url: getDomainName()+that.props.url,
					dataType: 'json',
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data) {
						globalVar.searchMenues.map(function(sm){
							sm.setState({data:data});
						});
						initiateSwiper();
						addSelectOnChange();
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err) {
						if(xhr.status == 401){
							$('#token').val('');
							makeRequestWithToken(that,globalVar.callBack);
						}
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalVar.callBack = callBack;
			if(globalVar.apiCalled == false){
				$('#spinner').show();
				makeRequestWithToken(this,callBack);
				globalVar.apiCalled = true;
			}
		},
		render: function() {

		var tabs = this.props.place == 'mob' ? <MobTab /> : <DeskTab />;
		return (
			<div>
				{tabs}
				<HomeSearch place={this.props.place} data={this.state.data} />
			</div>
		);
	  }
});

var MobTab = React.createClass({
	render : function(){
		return (
			<div className="tabOpts col-xs-12">
					<div className="btn-group btn-group-lg" role="group">
						<a className="btn btn-default active"> Home </a>
						<a className="btn btn-default"> Commercial </a>
						<a className="btn btn-default"> Land </a>
					</div>
			</div>
		);
	}
});

var DeskTab = React.createClass({
	render : function(){
		return (
			<div className="tabOpts col-xs-12">
						<a className="active"> Home </a>
						<a> Commercial </a>
						<a> Land </a>
			</div>
		);
	}
});

var MapPageButton = React.createClass({
	render : function(){
		var onChange = function(){
			showPage('map_page');
		}
		return (
			<div className="form-group">
			<br/>
						<button type="button" onClick={onChange} className="form-control btn">Map</button>
			</div>
		);
	}
})

var statenm = "States";
var substatenm = "Town";




var HomeSearch = React.createClass({
	render: function() {
		var stateChange = function(val,data,pre){
			if(data.state_n_lg && data.state_n_lg[val]){
				var d = data.state_n_lg[val];
				globalVar.mob[pre+'_SubState'].setState({data:d});
				globalVar.desk[pre+'_SubState'].setState({data:d});
				globalVar.desk_result[pre+'_SubState'].setState({data:d});
			}
		}
		var catChange = function(val,data,pre){	
			var d = val == 'Sale' ? data.for_sale_price_range : data.for_rent_price_range;
			globalVar.mob[pre+'_MaxPrice'].setState({data:d});
			globalVar.desk[pre+'_MaxPrice'].setState({data:d});
			globalVar.desk_result[pre+'_MaxPrice'].setState({data:d});
		}

        if(this.props.data.lg_display_name){
			substatenm = this.props.data.lg_display_name;
		}
		if(this.props.data.state_display_name) {
			statenm = this.props.data.state_display_name;
		}
		var roomOptons = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15+'];
		var structOptions = ['Apt','Flat','House','Banglow','Site','Uncompleted Building'];
		var comStructOptions = ['Office','Shope Space','Retail Unit','Parking','Hall','Office Share'];
		var landStructOptions = ['Acre','Plot'];
		var landSizeOptions = ['0.10','0.50','1','5','10','50','100','500','1000','2000','3000','4000','5000','10000+'];
		var comSizeOptions =  [ "150", "300", "500", "750", "1000", "1500", "2000", "3000", "4000", "5000", "10000", "15000", "50000", "100000"];
		this.props.data['categoryOptions'] = ['Sale','Letting'];
		var homeId = 'homeSearch_'+this.props.place;
		var comId = 'CommercialSearch_'+this.props.place;
		var landId = 'LandSearch_'+this.props.place;


		if(this.props.place == 'desk_result'){
			var mapButton = '';
		} else {
			var mapButton = '' ;
		}

		return (
			<div>
				<div className="tabContentn Home" id={homeId} >
					<form className="form-inline form-group-lg showMap" onsubmit="return false;">
					  <div className="form-group">
						<DropDown name='H_Category' dname="Category" place={this.props.place} field_name='category' datakey='categoryOptions' data={this.props.data} changeHandler={catChange}  />
					  </div>
					  <div className="form-group">
						<DropDown name='H_Type' dname="Type" place={this.props.place} field_name='a_property' data={structOptions}  />
					  </div>
					  <div className="form-group">
						 <DropDown name='H_Rooms' dname="Rooms" place={this.props.place}  field_name='max_size' data={roomOptons}  />
					  </div>
					  <div className="form-group">
						<DropDown name='H_States' dname={statenm} place={this.props.place} field_name='state' datakey='state' changeHandler={stateChange} data={this.props.data} />
					  </div>
					  <div className="form-group" >
						 <DropDown name='H_SubState' dname={substatenm} place={this.props.place} field_name='lg' />
					  </div>
					  <div className="form-group">
						<DropDown name='H_MaxPrice' dname="MaxPrice" place={this.props.place} field_name='max_price'  data={this.props.data.for_sale_price_range}  />
					  </div>
					  <div className="form-group">
						<button type="submit" className="form-control btn">Search</button>
					  </div>
					</form>
				</div>
				<div className="tabContentn hidden Commercial" id={comId}>
					<form className="form-inline form-group-lg">
					  <div className="form-group">
						<DropDown name='C_Category' dname="Category" place={this.props.place} field_name='category' datakey='categoryOptions' data={this.props.data} changeHandler={catChange}  />
					  </div>
					  <div className="form-group">
						<DropDown name='C_Type' dname="Type" place={this.props.place} field_name='a_property' data={comStructOptions}  />
					  </div>
					   <div className="form-group">
						<DropDown name='C_Measurement' dname="Measurement" place={this.props.place} field_name='max_size' data={comSizeOptions}  />
					  </div>
					  <div className="form-group">
						<DropDown name='C_States' dname={statenm} place={this.props.place} field_name='state' datakey='state' changeHandler={stateChange} data={this.props.data} />
					  </div>
					  <div className="form-group" >
						 <DropDown name='C_SubState' dname={substatenm} place={this.props.place} field_name='lg' />
					  </div>
					  <div className="form-group">
						<DropDown name='C_MaxPrice' dname="MaxPrice" place={this.props.place} field_name='max_price'  data={this.props.data.for_sale_price_range}  />
					  </div>
					  <div className="form-group">
						<button type="submit" className="form-control btn">Search</button>
					  </div>
					</form>
				</div>
				<div className="tabContentn hidden Land" id={landId}>
					<form className="form-inline form-group-lg">
					  <div className="form-group">
						<DropDown name='L_Category' dname="Category" place={this.props.place} field_name='category' datakey='categoryOptions' data={this.props.data} changeHandler={catChange}  />
					  </div>
					  <div className="form-group">
						<DropDown name='L_Type' dname="Type" place={this.props.place} field_name='a_property' data={landStructOptions}  />
					  </div>
					   <div className="form-group">
						<DropDown name='L_Measurement' dname="Measurement" place={this.props.place} field_name='max_size' data={landSizeOptions}  />
					  </div>
					  <div className="form-group">
						<DropDown name='L_States' dname={statenm} place={this.props.place} field_name='state' datakey='state' changeHandler={stateChange} data={this.props.data} />
					  </div>
					  <div className="form-group" >
						 <DropDown name='L_SubState' dname={substatenm} place={this.props.place} field_name='lg' />
					  </div>
					  <div className="form-group">
						<DropDown name='L_MaxPrice' dname="MaxPrice" place={this.props.place} field_name='max_price'  data={this.props.data.for_sale_price_range}  />
					  </div>
					  <div className="form-group">
						<button type="submit" className="form-control btn">Search</button>
					  </div>
					</form>
				</div>
				
			</div>
		);
	  }
});


var DropDown = React.createClass({
	getInitialState: function() {
			return {data: this.props.data};
	},
	onChangeHandler: function(event) {
		if(this.props.changeHandler){
			var prefix = this.props.name.split('_');
			this.props.changeHandler(event.target.value,this.props.data,prefix[0]);
		}
    },
	render : function(){
		globalVar[this.props.place][this.props.name] = this;
		var options = [];
		options.push(<Option key='-1' data={this.props.dname} />);
		
		if(this.state.data){
			var data = this.state.data;
			
			if(this.props.datakey){
				data = this.props.data[this.props.datakey];
			}
			if(data){
				for (var i=0; i < data.length; i++) {
					
					options.push(<Option key={i}  data={data[i]} />);
				}
			}
		}
		var className = "form-control "+this.props.name;
		return (
			<select onChange={this.onChangeHandler} name={this.props.field_name} data-name={this.props.name} className={className} >
				{options}
			</select>
		);
	}
});

var Option = React.createClass({
	render : function(){
		var v = this.props.data;
		
		
		if(typeof this.props.data === 'string'){
			v = this.props.data;
		} else {
			v = this.props.data[0];
		}
		return (
			<option value={v}>{v}</option>
		);
	}
});

ReactDOM.render(
  <SearchMenu place="mob" url="api/set-up-urls/" />,
  document.getElementById('search_menu')
);

ReactDOM.render(
  <SearchMenu place="desk" url="api/set-up-urls/" />,
  document.getElementById('search_menu2')
);

ReactDOM.render(
  <SearchMenu place="desk_result" type="result_menu" url="api/set-up-urls/" />,
  document.getElementById('results_menu')
);




searchTabs();













