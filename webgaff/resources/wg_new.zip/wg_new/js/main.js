var globalMainVars = {};
var viewCount=0;
var SwiperSlide = React.createClass({
	  render: function() {
		var prop = this.props.data;

       
		var typearr = prop.title.split("|");
		var oLogo =  React.createElement('img', {src : this.props.data.owner_logo_url,style : {width: "45px", height: "45px"}});
		var propPic = React.createElement('img', {src : prop.pictures[0] , className : 'propertyImg' , align : 'middle' });
		var title = React.createElement('h4', {style : {whiteSpace: "nowrap", width: "152px" , overflow: 'hidden'}},
            typearr[0],
            React.createElement('span',{className:'seperator'}),
            typearr[1]
        );
		var desc = React.createElement('p', {style : {height: "42px", width: "150px" , overflow: 'hidden'}},prop.description.text);
		var bathrooms = prop.details['Bathrooms'] ? React.createElement('div', {className : 'bathIcon' },prop.details['Bathrooms']) : '';
		var parking = prop.details['Parking Space'] ? React.createElement('div', {className : 'carIcon' },prop.details['Parking Space']) : '';
		var bedrooms = prop.details['Bedrooms'] ? React.createElement('div', {className : 'bedIcon' },prop.details['Bedrooms']) : '';
		var heightSpec = prop.details['Total Floor Area'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Total Floor Area']+' Sq.Ft.') : '';
		var sizes = prop.details['sizes'] ? React.createElement('div', {className : 'heightSpec' },prop.details['sizes']) : '';
		var Size = prop.details['Size'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Size']) : '';
		var ber = null;
		if(prop.ber){
			var berno = prop.ber;
			berno = berno.toLowerCase();
			ber = React.createElement('img', {src : 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/ber/ber_'+berno+'.png' , className : 'berImg' });
		}
          var onClickHandler = function(e){
			if($(e.target).hasClass('swiper-pagination-bullet') || $(e.target).hasClass('swiper-pagination') ){
				return false;
			}
			var detailUrl = $(e.target).closest('.swiper-slide').data('url');

            if (document.location.hostname != "localhost")
                var jsonurl=getDomainName()+'api/v1'+detailUrl;
            else
                var jsonurl = getDomainName()+'api/v1/property.php?slug='+detailUrl;

			var callBack = function(that,token){
				$.ajax({
                    url: jsonurl,
					dataType: 'json',
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data){

						globalMainVars.DetailsPageSlider.setState({data: data});
						globalMainVars.DetailsPageDetails.setState({data: data});
						showPage('details_page',detailUrl);
						window.setTimeout(function(){initiateDetailsSlider()},500);
						initializeMap(data.lat,data.lng,data.marker);
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err){
						if(xhr.status == 401){
							$('#token').val('');
							makeRequestWithToken(that,globalMainVars.currentCallBack);
						}
						if(xhr.status == 404){
							window.location.href = getDomainName()+'404.html';
						}
						$('#spinner').hide();
					}.bind(that)
				});
			}
			$('#spinner').show();
			globalMainVars.currentCallBack = callBack;
			makeRequestWithToken(globalMainVars.DetailsPageSlider,callBack);
		}
		return (
			<div className="swiper-slide dropShadow" data-url={prop.url} >
				<div className="card">
					<div className="cardImgWrap" onClick={onClickHandler}>
						{propPic}
						<div className="likeCheck">
							<input type="checkbox" id="property1" />
							<label for="property1" className="likeIcon"></label>
						</div>

                        {ber}
						<div className="authIcon">{oLogo}</div>
					</div>
					<div className="cardSpec row" onClick={onClickHandler}>
						<div className="cardDisc col-md-6">
							{title}
							{desc}
						</div>
						<div className="cardPrice col-md-6 pull-right">
							<p>{prop.price}</p>
						</div>
						<div className="col-xs-12 cardDtl">
							{bathrooms}
							{parking}
							{bedrooms}
							{heightSpec}
							{Size}
							{sizes}
						</div>
					</div>
				</div>
			</div>
		);
	  }
});

var SlideList = React.createClass({
		getInitialState: function() {
			return {data: {
				houses : [],
				lands : [],
				commercials : []
			}};
		},
		componentDidMount: function() {
			
			var callBack = function(that,token){
				$.ajax({
					url: getDomainName()+that.props.url,
					dataType: 'json',
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data) {
						that.setState({data: data});
						initiateSwiper();
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err) {
						if(xhr.status == 401){
							$('#token').val('');
							makeRequestWithToken(that,globalMainVars.currentCallBack);
						}
						
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			makeRequestWithToken(this,callBack);
		},
		render: function() {
		
		var index = 0;
		var houses = this.state.data.houses.map(function(property){
			index ++;
			return <SwiperSlide key={index} data={property} />
		});
		var lands = this.state.data.lands.map(function(property){
			index ++;
			return <SwiperSlide key={index} data={property} />
		});
		var commercials = this.state.data.commercials.map(function(property){
			index ++;
			return <SwiperSlide key={index} data={property} />
		});
		return (
			
			<div className="swiper-arrow-wrapper" >
				<div id="featured_swiper" className="swiper-container">
					<div className="swiper-wrapper">
						{commercials}
						{houses}
						{lands}
					</div>
				</div>
				<div id="featured_next" className="swiper-button-next hidden-xs hidden-sm Pright"></div>
				<div id="featured_prev" className="swiper-button-prev hidden-xs hidden-sm Pleft"></div>
			</div>
		);
	  }
});




$(document).ready(function(){
	$('#serachFormData').on('change',function(){
		var formData = $(this).val();
		var callBack = function(that,token){
			$.ajax({
				url: getDomainName()+that.props.url,
				type: 'POST',
				data: formData,
				cache: false,
				beforeSend: function(xhr){
					xhr.setRequestHeader('Authorization', basicAuth);
					xhr.setRequestHeader('Webgaff-token', 'token '+token);
				},
				success: function(data) {
					that.setState({data: data});
					globalMainVars.MapResultList.setState({data: data});
					showPage('results_page','/searchResults');
					$('.searchTabs.xs').removeAttr('style');
					
					initiateMapSwiper();
					initiateResultsMap(data.results);
					$('#spinner').hide();
				}.bind(that),
				error: function(xhr, status, err) {
					if(xhr.status == 401){
							$('#token').val('');
							makeRequestWithToken(that,globalMainVars.currentCallBack);
					}
					if(xhr.status == 404){
                        if ( $( "#searchResFailText" ).length ) {
                            $( "#searchResFailText" ).html('<div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div>');
                        }
                        else{
                            $('#search_menu2').append('<div id="searchResFailText"><div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div></div>');
                        }

							//window.location.href = getDomainName()+'404.html';
					}
					$('#spinner').hide();
				}.bind(that)
			});
		}
		globalMainVars.currentCallBack = callBack;
		$('#spinner').show();
		makeRequestWithToken(globalMainVars.ResultList,callBack);
	});
});


					

var MapResultsList = React.createClass({
	getInitialState: function() {
		var d = {results : []};
		return {data: d};
	},
	render : function(){
		globalMainVars.MapResultList = this;
		var results = [];
		var mapSwipeResults = [];
		if(this.state.data.results){
			var rs = this.state.data.results;
			for(var i=0;i<rs.length;i++){
				results.push(<Mapresult key={i} data={rs[i]} />);
				mapSwipeResults.push(<MapSwipeResult key={i} data={rs[i]} />);
			}
		}
		
		var pStyle = {height : '357px',position : 'relative'};
		return (
			<span>
				<div className="verticalCards hidden-xs hidden" id="map_results">
						{results}
				</div>
						
				<div className="mapSwiper swiper-arrow-wrapper visible-xs" style={pStyle} >
					<div id="map_swiper" className="swiper-container swiper-container-horizontal">
						<div className="swiper-wrapper" id="map_swipe_results">
							{mapSwipeResults}
						</div>            
					</div>
					 <div id="result_next" className="swiper-button-next hidden-xs hidden-sm"></div>
					 <div id="result_prev" className="swiper-button-prev hidden-xs hidden-sm"></div>
				</div>
			</span>
		);
	}
});




var ResultsList = React.createClass({
	getInitialState: function(){
		var d = {results : [] , next_page : '', previous_page : '' , current_page : ''};
		return {data: d};
	},
	render : function(){
		globalMainVars.ResultList = this;
		var results = [];
		if(this.state.data.results){
			var rs = this.state.data.results;
			for(var i=0;i<rs.length;i++){
				results.push(<Result key={i} data={rs[i]} />);
			}
		}

		var clickPageHandler = function(event){
			var type = $(event.target).data('type');
			
			var pageUrl = '';
			if(type == 'next'){
				pageUrl = globalMainVars.ResultList.state.data.next_page;
			} else {
				pageUrl = globalMainVars.ResultList.state.data.previous_page;
			}
			globalMainVars.pageUrl = pageUrl;
			
			var callBack = function(that,token){
				$.ajax({
					url: globalMainVars.pageUrl,
					type: 'GET',
					cache: false,
					beforeSend: function(xhr){
						xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data){
						that.setState({data: data});
						globalMainVars.MapResultList.setState({data: data});
						showPage('results_page','/searchResults');;
						$('.searchTabs.xs').removeAttr('style');
						
						 var swiper1 = new Swiper('.swiper1',{
							pagination: '.swiper-pagination1',
							paginationClickable: true,
							spaceBetween: 0,
							nextButton: '.swiper-button-next',
							prevButton: '.swiper-button-prev'

						});
						initiateMapSwiper();
						
						initiateResultsMap(data.results);
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err){
						if(xhr.status == 401){
								$('#token').val('');
								makeRequestWithToken(that,globalMainVars.currentCallBack);
						}
                        if(xhr.status == 404){
                            if ( $( "#searchResFailText" ).length ) {
                                $( "#searchResFailText" ).html('<div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div>');
                            }
                            else{
                                $('#search_menu2').append('<div id="searchResFailText"><div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div></div>');
                            }

                            //window.location.href = getDomainName()+'404.html';
                        }
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			$('#spinner').show();
			makeRequestWithToken(globalMainVars.ResultList,callBack);
		};
		
		var nextPageClass = (this.state.data.next_page == '' || this.state.data.next_page == this.state.data.current_page) ? 'hidden btn' : 'btn';
		var prevPageClass = (this.state.data.previous_page == '' || this.state.data.previous_page == this.state.data.current_page)? 'hidden btn' : 'btn';
	
		return (
			<div className="container results nopadding">
				{results}
				<div className="pagination-control">
					<button className={prevPageClass} data-type="prev" onClick={clickPageHandler}> Prev</button>
					<button className={nextPageClass} data-type="next" onClick={clickPageHandler}> Next  </button>
				</div>
			</div>
		);
	}
});

var Proppicture = React.createClass({
	render : function(){
		return (
			<div className="swiper-slide"><img src={this.props.imgurl} align="middle" className="propertyImg" /></div>					
		);
	}
});

var Result = React.createClass({
	render : function(){
		return(
			<div className="col-xs-12 col-sm-6 col-md-6 col-lg-4 nopadding">
				<Mapresult data={this.props.data} />
			</div>
		)
	}
});

var MapSwipeResult = React.createClass({
	render : function(){
		return(
			<div className="swiper-slide">
				<Mapresult data={this.props.data} />
			</div>
		)
	}
});

var Mapresult = React.createClass({
	render : function(){
		var prop = this.props.data;

        var typearr = prop.title.split("|");
		var oLogo =  React.createElement('img', {src : this.props.data.owner_logo_url,style : {width: "45px", height: "45px"}});
		var propPic = React.createElement('img', {src : prop.pictures[0] , className : 'propertyImg' , align : 'middle' });
		var title = React.createElement('h4', {style : {whiteSpace: "nowrap", width: "152px" , overflow: 'hidden'}},
            typearr[0],
            React.createElement('span',{className:'seperator'}),
            typearr[1]
        );
		var desc = React.createElement('p', {style : {height: "42px", width: "150px" , overflow: 'hidden'}},prop.description.text);
		var bathrooms = prop.details['Bathrooms'] ? React.createElement('div', {className : 'bathIcon' },prop.details['Bathrooms']) : '';
		var parking = prop.details['Parking Space'] ? React.createElement('div', {className : 'carIcon' },prop.details['Parking Space']) : '';
		var bedrooms = prop.details['Bedrooms'] ? React.createElement('div', {className : 'bedIcon' },prop.details['Bedrooms']) : '';
		var heightSpec = prop.details['Total Floor Area'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Total Floor Area']+'ha') : '';
		var sizes = prop.details['sizes'] ? React.createElement('div', {className : 'heightSpec' },prop.details['sizes']) : '';
		var Size = prop.details['Size'] ? React.createElement('div', {className : 'heightSpec' },prop.details['Size']) : '';
		var ber = null;
		if(prop.ber){
			var berno = prop.ber;
			berno = berno.toLowerCase();
			ber = React.createElement('img', {src : 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/ber/ber_'+berno+'.png' , className : 'berImg' });
		}
		var propPics = [];
		for(var j = 0; j < prop.pictures.length;j++){

			propPics.push(<Proppicture key={j} imgurl={prop.pictures[j]} />);
		}
		var onClickHandler = function(e){
			if($(e.target).hasClass('swiper-pagination-bullet') || $(e.target).hasClass('swiper-pagination') || $(e.target).hasClass('swiper-button-next') || $(e.target).hasClass('swiper-button-prev') || $(e.target).hasClass('likeCheck') ){

			}
			var detailUrl = $(e.target).closest('.cardWrap').data('url');

            var jsonurl=getDomainName()+'api/v1'+detailUrl;

			var callBack = function(that,token){
				$.ajax({
					url: jsonurl,
					dataType: 'json',
					beforeSend: function(xhr){
                        xhr.setRequestHeader('Authorization', basicAuth);
						xhr.setRequestHeader('Webgaff-token', 'token '+token);
					},
					success: function(data) {
						globalMainVars.DetailsPageSlider.setState({data: data});
						globalMainVars.DetailsPageDetails.setState({data: data});
										
						showPage('details_page',detailUrl);
						

						window.setTimeout(function(){initiateDetailsSlider()},500);
						initializeMap(data.lat,data.lng,data.marker);	
						$('#spinner').hide();
					}.bind(that),
					error: function(xhr, status, err) {
						if(xhr.status == 401){
							$('#token').val('');
							makeRequestWithToken(that,globalMainVars.currentCallBack);
						}
						if(xhr.status == 404){
							//window.location.href = getDomainName()+'404.html';
                            if ( $( "#searchResFailText" ).length ) {
                                $( "#searchResFailText" ).html('<div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div>');
                            }
                            else{
                                $('#search_menu2').append('<div id="searchResFailText"><div style="color: #ffffff; font-size: 40px;"><center>No Search Results Found</center></div></div>');
                            }

                        }
						$('#spinner').hide();
					}.bind(that)
				});
			}
			globalMainVars.currentCallBack = callBack;
			$('#spinner').show();
			makeRequestWithToken(globalMainVars.DetailsPageSlider,callBack);
		}

		return (
			
				<div className="cardWrap" data-url={prop.url}>
					<div className="card" >
						<div className="cardImgWrap internal">
							
							<div className="swiper-container swiper1">
								<div className="swiper-wrapper">
									{propPics}
								</div>
								<div className="swiper-pagination swiper-pagination1"></div>
								<div className="swiper-button-next"></div>
								<div className="swiper-button-prev"></div>
							</div>
							<div className="likeCheck">
								<input type="checkbox" id="property1" />
								<label for="property1" className="likeIcon"></label>
							</div>
                            {ber}
							<div className="authIcon">{oLogo}</div>
						</div>
						<div onClick={onClickHandler} className="cardSpec row">
							<div className="cardDisc col-md-6">
								{title}
								{desc}
							</div>
							<div className="cardPrice col-md-6 pull-right">
								<p>{prop.price}</p>
							</div>
							<div className="col-xs-12 cardDtl">
								{bathrooms}
								{parking}
								{bedrooms}
								{heightSpec}
								{Size}
								{sizes}
							</div>
						</div>
					</div>
				</div>
		);
	}
});



	var DetailsPageSlider = React.createClass({
		getInitialState: function() {
			globalMainVars.DetailsPageSlider = this;
			return {data:{}};
		},
		render : function(){
		
		var prop = this.state.data;
        console.log(prop);
        var ber = null;
        if(prop.ber){
            var bern = prop.ber;
            bern = bern.toLowerCase();
            ber = React.createElement('img', {src : 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/ber/ber_'+bern+'.png' , className : '' });
        }
		if(typeof prop.description == 'undefined'){
			return (<div className="swiper-container"></div>);
		}
		
		var propPics = [];
		for(var j = 0; j < prop.pictures.length;j++){

			propPics.push(<Proppicture key={j} imgurl={prop.pictures[j]} />);
		}
		
		return (
			<div id="detail_swiper_div" className="swiper-container swiper-container-horizontal">
					<div  className="swiper-wrapper">
						{propPics}
					</div>
					<div id="detail_swiper_pagination" className="swiper-pagination" ></div>
					<div id="details_next" className="swiper-button-next Pright"></div>
					<div id="details_prev" className="swiper-button-prev Pleft"></div>
					<div className="propSpec">
					<div className="container-fluid" id="details_fluid">
						<div className="row">
							<div className="col-xs-12 col-sm-6 nopadding">
								<h3 class="textShadow">{prop.description.title}</h3>
								<h4 class="textShadow">{prop.description.text}</h4>
								<div className="buttons hidden-xs">
									<button id="printDetailsPage" className="btn btn-default btnOrange cstPrint"> PRINT </button>
									<a id="mailDetailsPage" className="btn btn-default btnOrange"> EMAIL </a>
									<a id="sharebtn" className="btn btn-default btnBlue"> SHARE </a>
								</div>
							</div>
							<div className="col-xs-12 col-sm-6 propDetails hidden-xs">
								<div className="row">
									<div className="pull-right hidden">
										<div className="propIcon propView">
											Private Room
										</div>
										<div className="propIcon propGuest">
											2 Guests
										</div>
										<div className="propIcon propBed">
											1 Bed
										</div>
									</div>
									<div className="col-xs-12 propPhone">
										Ph: {this.state.data.owner_contact}
                                        <div className="textShadow">
                                            <p>Total Views: <span id="viewCountSpan">{viewCount}</span></p>
                                            <div className="row pull-right">
                                                <div className="col-xs-1">BER: </div>
                                                <div className="col-xs-1"> {ber}</div>
                                            </div>
                                        </div>
									</div>
								</div>
							</div>
							
							<div className="col-xs-12 col-sm-6 propDetails visible-xs">
								<div className="row">
									<div className="pull-left hidden">
										<div className="propIcon propView">
											Private Room
										</div>
										<div className="propIcon propGuest">
											2 Guests
										</div>
										<div className="propIcon propBed">
											1 Bed
										</div>
									</div>
									<div className="buttons pull-right">
										<button className="btn btn-default btnOrange cstPrint"> PRINT </button>
										<button className="btn btn-default btnOrange"> EMAIL </button>
										<button className="btn btn-default btnBlue"> SHARE </button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					
				</div>
			);
		}
	});
	
	var DetailBlock = React.createClass({
		render : function(){
			var detail = this.props.data;
			var detailName = detail.name.replace(/([A-Z])/g, ' $1').replace(/^./, function(str){ return str.toUpperCase(); })
			return (
				<div className="row">
                    <div className="col-xs-6 col-sm-5">{detailName}</div>
                    <div className="col-xs-6 col-sm-5">{detail.value}</div>
                </div>
			);
		}
	});
	var DetailsPageDetails = React.createClass({
		getInitialState: function(){
			globalMainVars.DetailsPageDetails = this;
			return {data:{}};
		},
		render : function(){
			var prop = this.state.data;
            if(Object.keys(prop).length === 0 && prop.constructor === Object) {
            }
            else{

                var ber = null;
				if(prop.ber){
					var bern = prop.ber;
					bern = bern.toLowerCase();
					ber = React.createElement('img', {src : 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/ber/ber_'+bern+'.png' , className : '' });
                }
				if (document.location.hostname != "localhost")
                    var viewsUrl = getDomainName()+'api/v1/property/listing-views/ '+prop.id+'/';
                else
                    var viewsUrl = getDomainName()+'api/v1/views.php';
            }
			if(typeof prop.description == 'undefined'){
				return (<div className="container"></div>);
			}
			var oLogo =  React.createElement('img', {src : prop.owner_logo_url ? prop.owner_logo_url : '',style : {width: "45px", height: "45px"}});
			var d = new Date(prop.owner_date_joined);
			var memberSince = getMemberSince(prop.owner_date_joined);
			var pStyle = {maxWidth:'260px'};
			var mapStyle={width:'100%',height:'300px'};
			var subject = "Enquiry About: "+getDomainName()+'api/v1'+prop.url;
            var contMsgStyle={ color : 'green', fontSize : '80%' };
            var features = prop.description.features;

            features = features.replace(/,/g,  ' + ');
            features = '+ '+features;

            $('#sharebtn').attr("href", prop.url);
            $('#printDetailsPage').bind("click", function(e) { window.print() });

            var email = 'sample@gmail.com';
            //var subject = 'Test';
            var emailBody = 'Hi Sample,';
			var DetailsBlocks = [];
			var ind = 0;

			for(var i in prop.details){
                if(prop.description.type=='commercial' && i=='Size')
                    var custValue = prop.details[i]+' Sq. Ft.';
                else
                    var custValue = prop.details[i];

				var d = { name : i , value : custValue };
				DetailsBlocks.push(<DetailBlock key={ind} data={d} />);
				ind++;
			}
            $('#mailDetailsPage').attr("href", "mailto:"+email+"?subject="+subject+"&body="+emailBody);

			return (
			<div className="container">
					<div className="row">
						<div className="col-xs-12">
							<div className="col-xs-12 rowTite col-sm-2">
								About this listing
							</div>  
							<div className="col-xs-12 col-sm-10">
								{prop.description.description}
							</div>
						</div>
						
						<div className="col-xs-12">
							<div className="col-xs-12 rowTite col-sm-2">
								Details
							</div>  
							<div className="col-xs-12 col-sm-10">
                                {DetailsBlocks}
							</div>
						</div>
                        <div className="col-xs-12">
                            <div className="col-xs-12 rowTite col-sm-2">
                            Features
                            </div>
                            <div className="col-xs-12 col-sm-10">
                                {features}
                            </div>
                        </div>
					</div>
					
					<div className="propMap row" style={mapStyle} id="map_canvas">
						
					</div>
					
					<div className="row quickContact">
						<div className="col-xs-12 col-sm-6">
							<div className="rowTite">
								About Advertiser
							</div>
							<div className="host">
								<div className="col-xs-12 hostTitle">
									<div className="hostIcon">
										{oLogo}
									</div>
									{prop.owner}
								</div>
								<div className="hostDetails">
									Member since: {memberSince}
								</div>
							</div>
						</div>
						
						<div className="col-xs-12 col-sm-6 contactForm">
							<div className="rowTite">
								Contact This Property
							</div>
							<div id="MessageBox" className="rowTite smallerFont colorGreen" style={contMsgStyle}>
							</div>
							<div className="form" data-type="contact-form" >
								<form className="contactForm" data-url={prop.owner_contact_url} >
								  <div className="form-group col-xs-12 col-sm-6">
									<input type="text" name="sender" className="form-control" id="senderCF" required="required" placeholder="Name" />
								  </div>
								  <div className="form-group col-xs-12 col-sm-6">
									<input type="email" name="email" className="form-control" id="emailCF" required="required" placeholder="Email" />
								  </div>
								  <div className="form-group col-xs-12">
									<textarea name="message" className="form-control" id="messageCF" required="required" rows="3" ></textarea>
									<input type="hidden" name="subject" value={subject} /> 
								  </div>
								  <div className="form-group col-xs-12">
									  <button type="submit" className="btn btn-default btnOrange sendBtn">SEND</button>
								  </div>
								</form>
							</div>
						</div>
					</div>
					
				</div>
			);
		}
	});








if(window.location.href.indexOf('property') != -1){
	$('#main_container').hide();
}

window.setTimeout(function(){
	ReactDOM.render(
	  <SlideList url="api/v1/" />,
	  document.getElementById('featuredSlider')
	);
	initiateSwiper();
},3000);

window.setTimeout(function(){

    ReactDOM.render(
      <ResultsList url="api/v1/search-form-submit/"  />,
      document.getElementById('searchResults')
	);

	ReactDOM.render(
	  <MapResultsList page='1' url="api/v1/search-form-submit/"  />,
	  document.getElementById('mapResults')
	);

	ReactDOM.render(
	  <DetailsPageSlider   />,
	  document.getElementById('details_slider')
	);
	
	ReactDOM.render(
	  <DetailsPageDetails   />,
	  document.getElementById('details_page')
	);

	if(window.location.href.indexOf('property') != -1){
		var urlParts = window.location.href.split('property');
		$('.container-fluid').addClass('hidden');

		if(!urlParts[1] || urlParts[1] == '' || urlParts[1] == null ){
			window.location.href = getDomainName()+'404.html';
		}
		var detailUrl = urlParts[1];
		var jsonurl=getDomainName()+'api/v1'+'/property'+detailUrl;
		var callBack = function(that,token){
					$.ajax({
						url: jsonurl,
						dataType: 'json',
						beforeSend: function(xhr){
							xhr.setRequestHeader('Authorization', basicAuth);
							xhr.setRequestHeader('Webgaff-token', 'token '+token);
						},
						success: function(data) {
							globalMainVars.DetailsPageSlider.setState({data: data});
							globalMainVars.DetailsPageDetails.setState({data: data});
							showPage('details_page','/property'+detailUrl);
							$('#main_container').show();
							window.setTimeout(function(){initiateDetailsSlider()},500);
							initializeMap(data.lat,data.lng,data.marker);	
							$('#spinner').hide();
						}.bind(that),
						error: function(xhr, status, err) {
							if(xhr.status == 401){
								$('#token').val('');
								makeRequestWithToken(that,globalMainVars.currentCallBack);
								$('#main_container').show();
							}
							if(xhr.status == 404){
								window.location.href = getDomainName()+'404.html';
								$('#main_container').show();
							}
							$('#spinner').hide();
						}.bind(that)
					});
				}
				globalMainVars.currentCallBack = callBack;
				$('#spinner').show();
				makeRequestWithToken(globalMainVars.DetailsPageSlider,callBack);
				
	
	} else {
		showPage('home_page','/');
	}
},4000);



