var global = {contactSubmit : false,swipers : [] , ResultsMap : null , results : []};
var basicAuth = 'Basic YWJpb2xhOnNvZ2FmZjE=';
function getDomainName(){

    if (document.location.hostname != "localhost")
	    return '/';

	return (window.location.href.indexOf('localhost') > -1) && 0 ? 'http://localhost/' : '';
}
function makeRequestWithToken(that,callBack,data){
	if($('#token').val() != ''){
		if(data){
			callBack(that,$('#token').val());
		} else {
			callBack(that,$('#token').val(),data);
		}
	} else {
        var jsonUrl=getDomainName()+'api/v1/obtain-auth-token/';
		$.ajax({
            url: jsonUrl,
			type: "GET",
			beforeSend: function(xhr){
				xhr.setRequestHeader('Authorization', basicAuth);
			},
			crossDomain: true,
			datatype: "json",
			contentType: "application/json",
			success: function (data, textStatus, jqXHR){
				$('#token').val(data.token);
				if(data){
					callBack(that,$('#token').val());
				} else {
					callBack(that,$('#token').val(),data);
				}
			},
			error: function (jqXHR, textStatus, errorThrown){
				$('#spinner').hide();
			}
		});
	}
}


function initiateSwiper(){
	$('.swiper-arrow-wrapper').css('height','260px');
	$('.swiper-arrow-wrapper').css('position','relative');
	var swiper = new Swiper('#featured_swiper', {


		nextButton: '#featured_next',
		prevButton: '#featured_prev',
		
		
		slidesPerView: 4,
		spaceBetween: 20,
		breakpoints: {
			1190: {
				slidesPerView: 4,
				spaceBetween: 20
			},
			960: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			780: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			640: {
				slidesPerView: 1,
				spaceBetween: 20
			}
		}
	});
	$('.likeCheck').on('click',function(){
		$(this).find('input').click();
	});
	global.featuredSwiper = swiper;
}


function initiateMapSwiper(){
	$('.mapSwiper').css('height','357px');
	$('.mapSwiper').css('position','relative');
	var swiper = new Swiper('#map_swiper', {


		nextButton: '#result_next',
		prevButton: '#result_prev',
		
		
		slidesPerView: 4,
		spaceBetween: 20,
		breakpoints: {
			1190: {
				slidesPerView: 4,
				spaceBetween: 20
			},
			960: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			780: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			640: {
				slidesPerView: 1,
				spaceBetween: 20
			}
		}
	});
	$('.likeCheck').unbind('click');
	$('.likeCheck').on('click',function(){
		$(this).find('input').click();
	});
}


function initiateDetailsSlider(){

	var swiper = new Swiper('#detail_swiper_div', {
        pagination: '#detail_swiper_pagination',
		nextButton: '.swiper-button-next',
		prevButton: '.swiper-button-prev',
        paginationClickable: true,
		autoplay : 2000
    });
	$('#detail_swiper_pagination').css('z-index','9999');
	$('.propMap').find('img').css('width','100%').css('height','auto');
	if($('.contactForm').length > 0 && global.contactSubmit == false){
		$('.contactForm').on('submit',function(){
			if(this.checkValidity()){
				fData = $(this).serialize();
				var url = $(this).data('url');
				var domain = getDomainName();
				domain = domain.slice(0, -1);
                if (document.location.hostname == "localhost")
                    var posturl=getDomainName()+'api/v1/property.php';
                else
                    var posturl = domain+url;
				var callBack = function(that,token){
					$.ajax({
						url: posturl,
						type: 'POST',
						data: fData,
						cache: false,
						beforeSend: function(xhr){
							xhr.setRequestHeader('Authorization', basicAuth);
							xhr.setRequestHeader('Webgaff-token', 'token '+token);
						},
						success: function(data) {
							$(that).html("Message Have Been Sent");
							$('#spinner').hide();
                            $('#messageCF').val('');
                            $('#senderCF').val('');
                            $('#emailCF').val('');
                            window.setTimeout(function(){
                                $(that).fadeOut( "slow",function() {
                                    $(that).html( "" );
                                    $(that).show();
                                });

                            },5000);
						}.bind(that),
						error: function(xhr, status, err) {
							if(xhr.status == 401){
								$('#token').val('');
								makeRequestWithToken(that,global.callBack);
							}
							$('#spinner').hide();
						}.bind(that)
					});
				}
			global.callBack = callBack;
			$('#spinner').show();
			makeRequestWithToken($('#MessageBox'),callBack);
				
			}
			return false;
		});
		global.contactSubmit = true;
	}
}

function searchTabs(){
	$('.tabOpts a').on('click', function(){
		$('.tabOpts a').removeClass('active');
		
		var t = $(this).html();
		$('.tabOpts a').each(function(){
			var html = $(this).html();
			if(t == html){
				$(this).addClass('active');
			}
		});
		t = t.trim();
		$('.tabContentn').addClass('hidden');
		$('.'+t).removeClass('hidden');
	});	
	
	$('form').on('submit',function(){
		var data = $(this).serialize();
		$('#serachFormData').val(data);
		$('#serachFormData').trigger("change");
		return false;
	});
}

function showPage(page,historyUrl){
	var hUrl = historyUrl ? historyUrl : page;
	$('.container-fluid').addClass('hidden');
	$('#'+page).removeClass('hidden');
	$('.jumbotron').addClass('hidden');
	if(page == 'home_page'){
		if(global.featuredSwiper){
			global.featuredSwiper.onResize();
		}
	}
	
	
	if(page != 'home_page' && page != 'details_page'){
		$('#main_container').addClass('internal');
	} else {
		$('#main_container').removeClass('internal');
		if(page == 'details_page'){
			$('.propertyScrolle').removeClass('hidden');
			$('#details_fluid').removeClass('hidden');
		} else{
			$('.homejumbo').removeClass('hidden');
		}
	}
	if(page == 'map_page'){
        $('img.berImg').css('right','10px');
		initiateResultsMap(global.results,'yes');
	}

	if(window.history && window.history.pushState){
		var searchObj = { page : page , hUrl : hUrl };
		window.history.pushState(searchObj,'WebGaff '+page,hUrl);
	}
	
	window.scrollTo(0,0);
	$('.likeCheck').unbind('click');
	$('.likeCheck').on('click',function(){
		$(this).find('input').click();
	});
	
	
	$.each(global.swipers,function(index,swiper){
		swiper.destroy(true,true);
	});
	global.swipers = [];
	$('.swiper1').each(function(){
	   var swiper =  new Swiper($(this),{
			pagination: $(this).find('.swiper-pagination1'),
			paginationClickable: $(this).find('.swiper-pagination1'),
			nextButton: $(this).find('.swiper-button-next'),
			prevButton: $(this).find('.swiper-button-prev'),
			spaceBetween: 0,
			observer : true
		});
		global.swipers.push(swiper);
	});
}

function getMemberSince(dateStr){
	var monthNames = [
	  "January", "February", "March",
	  "April", "May", "June", "July",
	  "August", "September", "October",
	  "November", "December"
	];

	var date = new Date(dateStr);
	var day = date.getDate();
	var monthIndex = date.getMonth();
	var year = date.getFullYear();
	return  monthNames[monthIndex]+' '+year;
}
function initializeMap(lat,lang,marker){
	if(typeof lat !== 'undefined' && typeof lang !== 'undefined'){
		var myLatlng = new google.maps.LatLng(lat, lang);
		var myOptions = {
			zoom: 10,
			center: myLatlng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		}
		var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
		var beachMarker = new google.maps.Marker({
			position: myLatlng,
			map: map,
			icon: 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/map_icon.png',
		});
	}
}

function initiateResultsMap(results, show){
	global.results = results;
	if(results[0] && show == 'yes'){
		var myLatlng = new google.maps.LatLng(parseFloat(results[0].lng), parseFloat(results[0].lat));

		var myOptions={
				zoom: 12,
                center: {lat: parseFloat(results[0].lat), lng: parseFloat(results[0].lng)},
				mapTypeId: google.maps.MapTypeId.ROADMAP
		}

		$('#results_map').html('');
		var ResultsMap = new google.maps.Map(document.getElementById("results_map"), myOptions);
		var beachMarker = new google.maps.Marker({
				position: {lat: parseFloat(results[0].lat), lng: parseFloat(results[0].lng)},
				map: ResultsMap,
                zoom: 3,
				icon: 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/map_icon.png'
		});
		$.each(results,function(index,result){
			if(index > 10){
			}
			var myLatlng = new google.maps.LatLng(parseFloat(result.lng), parseFloat(result.lat));

			var beachMarker = new google.maps.Marker({
				position: {lat: parseFloat(result.lat), lng: parseFloat(result.lng)},
				map: ResultsMap,
                zoom: 3,
				icon: 'https://s3-eu-west-1.amazonaws.com/webgaff/static/images/map_icon.png'
			});
		});
		global.ResultsMap = ResultsMap;
	}
};

$(document).ready(function(){
    var n = window.location.href.indexOf("admin");
    if(n==-1) {
        $(".popout-btn").on('click', function(){
            $(".popupWrap").fadeIn('slow');
        });
        $(".close").on('click', function(){
            $(".popupWrap").fadeOut('slow');
        })

        $(window).on('popstate', function (event) {
            if (event.originalEvent && event.originalEvent.state && event.originalEvent.state.page) {
                window.history.go(-1);
                showPage(event.originalEvent.state.page, event.originalEvent.state.hUrl);
            }
        });
    }
});

function addSelectOnChange(){
	$('select').on('change',function(){
		$('.'+$(this).data('name')).val($(this).val());
			
	});
}
var loadViews = function(jsonurl) {
    var views=0;
    $.ajax({
        url: jsonurl,
        type: 'GET',
        cache: false,
        dataType: 'json',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', basicAuth);
            xhr.setRequestHeader('Webgaff-token', 'token ' + token);
        },
        success: function (data) {
            $('#viewCountSpan').html(data.times_visited);
            viewCount = data.times_visited;
        },
        error: function(){

        }
    });

}




function makeRequestWithTokenCookie(that,callBack,rData){
	if(getCookie('web-gaff-token') != null){
		if(rData){
			callBack(that,getCookie('web-gaff-token'),rData);
		} else {
			callBack(that,getCookie('web-gaff-token'));
		}
	} else {
       
        var jsonUrl=getDomainName()+'api/v1/obtain-auth-token/';
		$.ajax({
            url: jsonUrl,
			type: "GET",
			beforeSend: function(xhr){
				xhr.setRequestHeader('Authorization', basicAuth);
			},
			crossDomain: true,
			datatype: "json",
			contentType: "application/json",
			success: function (data, textStatus, jqXHR){

				setCookie('web-gaff-token',data.token,1);
				if(rData){
					callBack(that,getCookie('web-gaff-token'),rData);
				} else {
					callBack(that,getCookie('web-gaff-token'));
				}
			},
			error: function (jqXHR, textStatus, errorThrown) {

				$('#spinner').hide();
			}
		});
	}
}

function login(){
	var user = $('#user').val();
	var password = $('#password').val();
	$('#message').html('Trying to Login ...');
	var callBack = function(that,token){
		$.ajax({
			type: "POST",
			dataType: 'json',
			url: getDomainName()+'api/v1/login/',
			data : $('#login-form').serialize(),
			
			beforeSend: function(xhr){
				xhr.setRequestHeader('Authorization', basicAuth);
				xhr.setRequestHeader('Webgaff-token', 'token '+token);
			},
			success: function(data) {
				var str = JSON.stringify(data);
				setCookie('web-gaff-login-response',str);

				if(data.is_authenticated == true){
					var username = data.user_object.username;
					setCookie('web-gaff-is-logged-in','yes');
					setCookie('web-gaff-user',username);
					setCookie('web-gaff-user-name',data.user_object.name);
					setCookie('web-gaff-user-logo',data.user_object.user_logo);
					window.location.href = getDomainName()+'admin.html';
				} else {
					$('#message').html('Invalid Credentials');
				}
			},
			error: function(xhr, status, err) {
				if(xhr.status == 401){
					$('#message').html('Invalid Credentials');
				}
				$('#spinner').hide();
			}.bind(that)
		});
	}
	makeRequestWithTokenCookie(null,callBack);
	return false;
}

function logout(){
	removeCookie('web-gaff-is-logged-in');
	removeCookie('web-gaff-user');
	removeCookie('web-gaff-login-response');
	removeCookie('web-gaff-user-name');
	removeCookie('web-gaff-user-logo');
	var callBack = function(that,token){
		$.ajax({
			type: "GET",
			dataType: 'json',
			url: getDomainName()+'api/v1/logout/',
			data : $('#login-form').serialize(),
			
			beforeSend: function(xhr){
				xhr.setRequestHeader('Authorization', basicAuth);
				xhr.setRequestHeader('Webgaff-token', 'token '+token);
			},
			success: function(data) {
				removeCookie('web-gaff-is-logged-in');
				removeCookie('web-gaff-user');
				removeCookie('web-gaff-login-response');
				removeCookie('web-gaff-user-name');
				removeCookie('web-gaff-user-logo');
				window.location.href = getDomainName()+'login.html';
			},
			error: function(xhr, status, err) {
				if(xhr.status == 401){
					removeCookie('web-gaff-token');
					makeRequestWithTokenCookie(that,callback);
				}
				$('#spinner').hide();
			}.bind(that)
		});
	}
	makeRequestWithTokenCookie(null,callBack);
}

function setCookie(name, value, hours) {
    var expires;
	hours = hours ? hours : 1;
    if (hours) {
        var date = new Date();
        date.setTime(date.getTime() + (hours  * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    } else {
        expires = "";
    }
    document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = encodeURIComponent(name) + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
    return null;
}

function removeCookie(name) {
    setCookie(name, "", -1);
}
$(document).ready(function(){
    $('.btn').mouseout(function() {
            $(this).removeClass('dropShadow');
        })
        .mouseover(function() {
            $(this).addClass('dropShadow');
        });
    var pathname = window.location.pathname;
    if (document.location.hostname == "localhost"){
        if(pathname=='/wg_new_lat/wg_new/')
            pathname='/';
    }
    if(pathname!='/')
        $('.header').css('background-color','#fd7200');
});
$(document).keyup(function(e) {
    if (e.keyCode === 27)
    {
        hidePopUp();
    }
});
$(document).ready(function(e) {
    $(".popupWrap").click(function() {
        hidePopUp();
    });
});
function hidePopUp()
{
    $(".popupWrap").fadeOut('slow');
}

$(document).keyup(function(e) {
    if (e.keyCode === 27)
    {
        hidewall();
    }
});
$(document).ready(function(e) {
    $(".background").click(function () {
        hidewall();
    });
});
function hidewall()
{
    $(".background").fadeOut('slow');
    $(".foreground").fadeOut('slow');
}
function showwall(data)
{
    $(".foreground").html(data);
    $(".background").fadeIn('slow');
    $(".foreground").fadeIn('slow');
    if($(window).height()>$('.foreground').outerHeight()) {
        $('.foreground').css({
            left: ($(window).width() - $('.foreground').outerWidth()+20) / 2,
            top: ($(window).height() - $('.foreground').outerHeight()) / 2
        });
    }
    else{
        $('.foreground').css({
            left: ($(window).width() - $('.foreground').outerWidth()) / 2,
            top: 60+'px'
        });
    }
}
function loadPage(file){
    $.ajax({
        url: getDomainName()+file+'.html',
        type: 'GET',
        success: function(data) {
            showwall(data);
        },
        error: function() {
            alert("Oppsssss!");
        }
    });
}