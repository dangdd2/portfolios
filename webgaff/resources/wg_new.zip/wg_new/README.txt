/* Setup In Local */

1) Install Apache(or any other webserver that supports php) in system

2) Keep mode_rewrite on

3) Place this entire folder at server document root of the server
(so the url will be like http://localhost/wg_new/ ) 

This will use dmmy apis located within this folder



/* Setup on server */

1) Place contents of this folder into document root

2) update getDomainName is function to 

function getDomainName(){
	//FOR production 
	 return '/';
	// FOR localhost
	//return 'http://localhost/wg_new/';
}

which is located at js/common_functions.js

This will use the apis of the webgaff server