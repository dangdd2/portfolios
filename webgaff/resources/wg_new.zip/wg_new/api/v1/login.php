<?php 
	echo '{
"is_authenticated": true,
"message": "ok",
"user_object": {
"username": "jason-frills",
"user_logo": "https://webgaff.s3.amazonaws.com/media/images/main/K2htb2dJVlczTi9JM2IvWjR6S2tVbUtmQVpYVG5aQ2NsNUZZaVNvbXFxRTZaTk83VFRwWldCdkRPZWtESVkzdWhZQmFPOGlzK2pDY1BzK0VmZkwwK0xoYWFmSFhSL0Q4VEFzQmJBRHNEOHo4VHczV1JQYy9SVm00U2lpcXFobXk.png",
"can_add_property": true,
"name": "Jfrills",
"type": "Agency",
"email": "jasson@me.com",
"permissions": {
"property_add_permission": 5,
"document_add_permission": 5,
"allow_permissions_across_branches": "5",
"tenancy_edit_permission": 5,
"file_edit_permission": 5,
"tenancy_add_permission": 5,
"property_view_permission": 5,
"landlord_view_permission": 5,
"tenancy_view_permission": 5,
"document_delete_permission": 5,
"file_delete_permission": 5,
"file_view_permission": 5,
"document_edit_permission": 5,
"landlord_add_permission": 5,
"property_edit_permission": 5,
"tenancy_delete_permission": 5,
"document_view_permission": 5,
"landlord_delete_permission": 5,
"property_delete_permission": 5,
"file_add_permission": 5,
"landlord_edit_permission": 5
}
}
}';


/*

username:jasonfrills
From:
abiola rasheed

password:123456


Listing: /api/v1/{agent_user_name}/get-agent-property/?status=listed
Not listed: /api/v1/{agent_user_name}/get-agent-property/?status=pending
Rentals; /api/v1/{agent_user_name}/get-agent-property/?status=letting
For Sale: /api/v1/{agent_user_name}/get-agent-property/?status=sale
Occupied: /api/v1/{agent_user_name}/get-agent-property/?status=occupied
Migrated: /api/v1/{agent_user_name}/get-agent-property/?status=migrated
Sold: /api/v1/{agent_user_name}/get-agent-property/?status=sold


*/

// AIzaSyDsHSQ_MkfS0RUGBHXhSs80cqRUSw7SxbA

?>