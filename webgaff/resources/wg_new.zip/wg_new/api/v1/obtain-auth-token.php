<?php 
	header('Content-Type: application/json');
	echo '{"token":"c6b79e3ea82f89c6399e611eb287c33686ff9852"}';
?>