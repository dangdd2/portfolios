<?php
header('Content-Type: application/json');
$array = ['times_visited'=>189];
echo json_encode($array);
?>